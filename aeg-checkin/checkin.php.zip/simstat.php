<?php
$now = time();
$club = $_GET['club'];
$lag = $_GET['lag'];
$avs = $_GET['avs'];
mysql_connect("localhost","rose_streams","v0Ip83cH");
mysql_select_db("rose_streams");
mysql_query("UPDATE `simstats` SET `timestamp` = '$now', `lag` = '$lag', `avs` = '$avs' WHERE `club` = '$club'");

?>