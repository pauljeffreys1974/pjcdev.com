<?php
$time = time();
$name = $_GET['name'];
$club = $_GET['club'];
$role = $_GET['role'];
mysql_connect("localhost","rose_streams","v0Ip83cH");
mysql_select_db("rose_streams");
mysql_query("INSERT INTO `checklog` VALUES (NULL,'$club','$role','$name','$time')");
?>