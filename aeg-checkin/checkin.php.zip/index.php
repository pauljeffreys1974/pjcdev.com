<?php
$hud = $_GET['hud'];

			?>
			<html>
			<head>
			<title>AEG Check-In</title>
			<meta http-equiv="refresh" content="30; url=http://check-in.sonicrose.com/manager.php?hud=<?= $hud ?>&key=<?= $key ?>">
			<style>
			.mytd
			{
			border-right:1px solid white;
			padding: 0px;
			}
			</style>
			</head>
			<body link="#ffffff" vlink="#ffffff" bgcolor="#000000" text="#ffffff" style="font-family:Verdana, Arial, serif;">
			<form><input type=hidden name=key value=<?= $key ?>><input type=hidden name=hud value=<?= $hud ?>><input type=submit name=submit value="Refresh">
		
			<?php
			date_default_timezone_set('America/Los_Angeles');
			mysql_connect("localhost","rose_streams","v0Ip83cH");
			mysql_select_db("rose_streams");
			$hrago = time() - 4800;
			$time = time();
			$name = $_GET['name'];
			$club = $_GET['club'];
			$role = $_GET['role'];
			
			$tabledata = "";
			if($submit == "OK")
			{
				mysql_query("INSERT INTO `checklog` VALUES (NULL,'$club','$role','$name','$time')");
			}
			if($submit == "Remove Selected")
			{
				foreach($_GET as $key => $value)
				{
					if(substr($key,0,6) == "check-")
					{
						$record = substr($key,6);
						mysql_query("DELETE FROM `checklog` WHERE `recordId` = '$record'");
					}
				}
			}
			$sensors = mysql_query("SELECT `club`,`result`,`avs`,`slurl` FROM `sensors` ORDER BY `recordId`");
			$colcount = 0;
			while($row = mysql_fetch_array($sensors))
			{
				$colcount++;
				if ($colcount == 4 && $hud == 1) $tabledata .= "</tr><tr>";
				$checkinlist = "";
				extract($row);
				$clubtotal += $avs;
				$result = str_replace(", ",",",$result);
				if ($hud) $width = "width=33%";
				$tabledata .= "<td $width align=center valign=top class=mytd><hr /><table><tr><td colspan=3 align=center><b><a href=$slurl>$club</a></b><i>($avs)</i></td></tr>";
				$checklog = mysql_query("SELECT `recordId`,`role`,`name`,`timestamp` FROM `checklog` WHERE `timestamp` > '$hrago' AND `club` = '$club' ORDER BY `role` DESC");
				while($row2 = mysql_fetch_array($checklog))
				{
					extract($row2);
					$checkinlist .= $name . ",";
					if(strpos($result,$name) === false) $stat = "off";
					else $stat = "on";
					if (!$hud) $name = str_replace(" Resident","",$name);
					else
					{
					 	$name = explode(" ",$name);
						if(strlen($name[0]) > 9) $name[0] = substr($name[0],0,6) . "...";
						$name = $name[0]." ".$name[1];
						$name = str_replace(" ","<br />", $name);
					}
					$tabledata .= "<tr><td align=center><img height=24 src=\"$role-$stat.png\" /></td><td width=100px>$name</td><td></td></tr>";
				}
				$result = explode(",",$result);
				foreach ($result as $y => $x)
				{
					if(@strpos($checkinlist,$x) === false) 
					{
						if (!$hud) $x = str_replace(" Resident","",$x);
						else
						{
							$name= explode(" ",$x);
							if(strlen($name[0]) > 9) $name[0] = substr($name[0],0,6) . "...";
							$x = $name[0]." ".$name[1];
							$x = str_replace(" ","<br />", $x);
						}
						$tabledata .= "<tr><td></td><td>$x</td><td></td></tr>";
					}
				}
				
				$tabledata .= "</table></td>";
			}
			if ($hud) $width = "width=33%";
			$tabledata .= "</table></td>";
			?>
			Total: <?= $clubtotal ?>
			<table <?php if ($hud) echo("width=488px"); ?>>
			<tr><?= $tabledata ?></tr>
			</table>
			</form>
			<hr />
			</table>
			</body>
			</html>
			<?

?>