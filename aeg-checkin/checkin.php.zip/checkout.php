<?php
$hrago = time() - 3600;
$name = $_GET['name'];
mysql_connect("localhost","rose_streams","v0Ip83cH");
mysql_select_db("rose_streams");
mysql_query("DELETE FROM `checklog` WHERE `name` = '$name' AND `timestamp` > '$hrago'");
?>