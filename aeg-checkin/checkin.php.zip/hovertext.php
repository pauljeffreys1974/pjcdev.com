<?php
$club = $_GET['club'];
mysql_connect("localhost","rose_streams","v0Ip83cH");
mysql_select_db("rose_streams");
date_default_timezone_set('America/Los_Angeles');
$hrago = time() - 3600;
$result = mysql_query("SELECT `role`,`name` FROM `checklog` WHERE `timestamp` > '$hrago' AND `club` = '$club' ORDER BY `role` DESC");
if(mysql_num_rows($result))
{
	echo("Coming Up Next:\n");
	while($row = mysql_fetch_array($result))
	{
		extract($row);
		$name = str_replace(" Resident","",$name);
		echo("$role $name\n");
	}
}
else
{
	echo("No check-ins yet.");
}