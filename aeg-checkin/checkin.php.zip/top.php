<html>
<head>
<title>Top Roles</title>
</head>
<body>
<table>
<tr><td colspan=3>Past 7 Days</td></tr>
<tr>
<?php
mysql_connect("localhost","rose_streams","v0Ip83cH");
mysql_select_db("rose_streams");
$sevenago = time() - (86400*7);
$roles[] = "Dancer";
$roles[] = "DJ";
$roles[] = "Bartender";
foreach($roles as $x)
{
	$result = mysql_query("SELECT  `name`, COUNT( 1 ) AS  `checks` FROM  `checklog` WHERE `role` = '$x' AND `timestamp` > '$sevenago' GROUP BY  `name` ORDER BY  `checks` DESC");
	$y = 1;
	echo("<td valign=top>$x<br />");
	while($row = mysql_fetch_array($result))
	{
		extract($row);
		echo("$y. $checks $name<br />");
		$y++;
	}
	echo("</td>");
}
?>
</tr>
<tr><td colspan=3>All-Time</td></tr>
<tr>
<?php
foreach($roles as $x)
{
	$result = mysql_query("SELECT  `name`, COUNT( 1 ) AS  `checks` FROM  `checklog` WHERE `role` = '$x' GROUP BY  `name` ORDER BY  `checks` DESC");
	$y = 1;
	echo("<td valign=top>$x<br />");
	while($row = mysql_fetch_array($result))
	{
		extract($row);
		echo("$y. $checks $name<br />");
		$y++;
	}
	echo("</td>");
}
?>
</tr></table></body></html>