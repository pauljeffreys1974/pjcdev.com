<?php
$club = $_GET['club'];
$result = $_GET['result'];
$avs = $_GET['avs'];
echo("$club - $result");
mysql_connect("localhost","rose_streams","v0Ip83cH");
mysql_select_db("rose_streams");
mysql_query("UPDATE `sensors` SET `result` = '$result', `avs` = '$avs' WHERE `club` = '$club'");
?>